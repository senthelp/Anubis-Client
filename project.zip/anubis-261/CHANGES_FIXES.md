# Manual fixes applied on top of the port (attempt 2 state: 323 errors)

## High confidence (mechanical / confirmed by the compiler's own hints)
- 19 leaked intermediary names replaced (field_1774 -> keyboardHandler, field_1687 -> level, field_1724 -> player,
  field_1690 -> options, field_1761 -> gameMode, field_1772 -> font, field_1773 -> gameRenderer,
  field_4012 -> itemInHandRenderer, field_54155 -> keyPresses, field_7512 -> containerMenu,
  Options keys: keyUse/keyAttack/keyJump/keyShift/keyUp/keyDown/keyLeft/keyRight/keySwapOffhand)
- ChunkPos.asLong(x,z) -> ChunkPos.pack(x,z); chunkPos.toLong() -> .pack()
- GuiGraphics -> GuiGraphicsExtractor (all files)
- ChallengeToast.render -> extractRenderState
- ClientboundSetEntityMotionPacket getId()/getMovement() -> id()/movement()
- Screens.getButtons -> Screens.getWidgets
- Entry / Block import clashes (StaffListModule, AnchorGuard) resolved with qualified names
- Indigo mixin: renderLayer -> chunkLayer, target switched to a string (optional config, fails soft)

## Unverified guesses (could not compile here; check next CI run)
- ClickType -> net.minecraft.world.inventory.ContainerInput
- Fabric KeyBindingHelper -> keymapping.v1.KeyMappingHelper, registerKeyBinding -> registerKeyMapping

## Disabled (target classes no longer exist; features degraded)
- MixinLightTexture (fullbright/xray lightmap hooks), MixinLiquidBlockRenderer -> removed from anubis.mixins.json

## Still needs real API porting
Render pipeline (ShaderEspPass, ShaderOverlay, ItemIcons, BlockIcons, AuraBlur, ColorGradingPass, MotionBlurPass,
HandAuraPass, SkyMesh, AtmosphereShaderSky, JumpCirclesModule: DepthTestFunction, withBlend/withoutBlend,
PerspectiveProjection/CachedOrtho matrix buffers, isPanoramicMode, ItemBlockRenderTypes, getBlockRenderer),
RenderTypes.entityCutoutNoCull / itemEntityTranslucentCull, CardinalLightType, CameraRenderState/SkyRenderState/
WeatherRenderState/LevelRenderState mixins, entityAttackRange / isWithinAttackRange / interactOn,
ServerboundInteractPacket.dispatch, TimeChanger getDayTime/setDayTime, ChatComponent.addMessage, OptionsScreen ctor,
Window/Switchable, MipmapGenerator.generateMipLevels, SpawnEggItem Optional<Holder<Item>>, BlockAndTintGetter.

## Round 2 (from CI run with 99 errors)
- handleInventoryMouseClick -> handleContainerInput (confirms ContainerInput guess was right; KeyMappingHelper also compiled)
- GuiGraphicsExtractor: drawString -> text, renderFakeItem -> fakeItem
- RenderTypes.entityCutoutNoCull -> entityCutout, itemEntityTranslucentCull -> entityTranslucentCullItemTarget
- ChargedProjectiles.getItems -> itemCopies; ResourceLoader.registerReloader -> registerReloadListener
- Window -> Switchable cast routed through Object
- build.sh now appends an API dump (apidump.py) to port-report.txt when compile fails

## Round 3
- Render pipeline builder ported: withBlend/withoutBlend/withColorWrite -> withColorTargetState(ColorTargetState),
  withDepthWrite/withDepthTestFunction -> withDepthStencilState(...)  (8 files)
- entityAttackRange() -> getAttackRangeWith(mainHandItem); isWithinAttackRange(+ItemStack); interactOn(+Vec3)
- Screens moved to the extract model: render -> extractRenderState, renderBackground -> extractBackground
- ChatComponent.addMessage -> addClientSystemMessage; graphics.renderItem -> item; OptionsScreen ctor +false
- Projection buffers: PerspectiveProjectionMatrixBuffer -> ProjectionMatrixBuffer; ortho one -> Projection.setupOrtho
- DamageSource HolderSet check via set.contains(typeHolder()); SpawnEggItem.byId Optional handled
- Xray alphaFor now takes BlockGetter; panoramic-mode check stubbed to true (TODO)
- apidump.py extended (clocks, CardinalLighting, Transparency, item rendering, attack packet, ...)

## Round 4 (22 errors left)
- TimeChanger rewritten for the new clock system: MixinTimeChangerClockManager overrides overworld getTotalTicks
- CrystalOptimizer: attack detection now via ServerboundAttackPacket
- CardinalLighting.Type, Transparency arg for mip generation, FeatureRenderDispatcher ctor, BlockStateModelSet/BlockTintSource
- ItemBlockRenderTypes gone: translucent check approximated with HalfTransparentBlock; Xray SectionCompiler mixin disabled
- New CI step: mixincheck.py statically verifies mixin target methods against the real jars

## Round 5 (code COMPILES; jar step failed on duplicate LICENSE)
- build.gradle: jar duplicatesStrategy = EXCLUDE
- mixins config: defaultRequire 1 -> 0 so a stale hook logs a warning instead of crashing the game at launch
- mixincheck.py --fix: auto-renames render* mixin targets to extract* when the new method exists; reports candidates for the rest

## Round 6 (jar builds; mixin hooks)
- Auto-renamed 28 render* hooks to extract* (done by CI, now kept in source)
- Camera hook: setup -> update(DeltaTracker); custom FOV now hooks Camera.getFov(); FoglessLines uses camera.getFov()
- MultiPlayerGameMode: interact now takes EntityHitResult (interactAt merged); sneak packet ctor descriptor updated
- Xray ModelBlockRenderer hook disabled (target gone)
- Checker: <init> false positives fixed; apidump now always runs and searches for the new frame-swap / name-tag methods
- Still open: ImGui frame-swap hook (Window.updateDisplay gone), vanilla name-tag suppression, mob-effect sky hook,
  hand-layer accessor (LayerRenderState.transform), Freelook invokes inside Camera.update unverified

## Round 7
- ImGui frame hook moved to RenderSystem.flipFrame(TracyFrameCapture) (static inject)
- Vanilla name-tag suppression moved to AvatarRenderer.submitNameDisplay (exact descriptor)
- Removed stale interactAt gate and blindness-sky hook; hand accessor field -> itemTransform (unverified)

## Round 8 (first launch crash, from latest.log)
- MixinSpamMinecraft: Minecraft.disconnect now takes (Screen, boolean) -> dropped the extra boolean (this was the launch crash)
- mixincheck.py now also checks @Inject handler parameter lists against the real target signatures
  ("SIGNATURE MISMATCH" lines) because a wrong descriptor crashes the game at launch even with defaultRequire 0

## Round 9
- Rendering hooks ported to the new LevelRenderer API (renderLevel now gets CameraRenderState, not Camera/Matrix4f):
  Render3DEvent dispatch (TAIL, order 500), ShaderOverlay, ShaderEsp, fog-for-hand; underwater on-top-fog hook removed
- Weather hook, jump-circles hook and atmosphere fog hook signatures corrected
- mixincheck.py: stricter checks (@Inject / @WrapMethod / @ModifyReturnValue signatures, @Local(argsOnly) types, callback kind)
  and --fix now NEUTRALISES any hook that would crash launch (renames its target so it is skipped with a warning)
