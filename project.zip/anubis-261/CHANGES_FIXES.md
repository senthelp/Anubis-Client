# Manual fixes applied on top of the port (attempt 2 state: 323 errors)

## High confidence (mechanical / confirmed by the compiler's own hints)
- 19 leaked intermediary names replaced (field_1774 -> keyboardHandler, field_1687 -> level, field_1724 -> player,
  field_1690 -> options, field_1761 -> gameMode, field_1772 -> font, field_1773 -> gameRenderer,
  field_4012 -> itemInHandRenderer, field_54155 -> keyPresses, field_7512 -> containerMenu,
  Options keys: keyUse/keyAttack/keyJump/keyShift/keyUp/keyDown/keyLeft/keyRight/keySwapOffhand)
- ChunkPos.asLong(x,z) -> ChunkPos.pack(x,z); chunkPos.toLong() -> .pack()
- GuiGraphics -> GuiGraphicsExtractor (all files)
- ChallengeToast.render -> extractRenderState
- ClientboundSetEntityMotionPacket getId()/getMovement() -> id()/movement()
- Screens.getButtons -> Screens.getWidgets
- Entry / Block import clashes (StaffListModule, AnchorGuard) resolved with qualified names
- Indigo mixin: renderLayer -> chunkLayer, target switched to a string (optional config, fails soft)

## Unverified guesses (could not compile here; check next CI run)
- ClickType -> net.minecraft.world.inventory.ContainerInput
- Fabric KeyBindingHelper -> keymapping.v1.KeyMappingHelper, registerKeyBinding -> registerKeyMapping

## Disabled (target classes no longer exist; features degraded)
- MixinLightTexture (fullbright/xray lightmap hooks), MixinLiquidBlockRenderer -> removed from anubis.mixins.json

## Still needs real API porting
Render pipeline (ShaderEspPass, ShaderOverlay, ItemIcons, BlockIcons, AuraBlur, ColorGradingPass, MotionBlurPass,
HandAuraPass, SkyMesh, AtmosphereShaderSky, JumpCirclesModule: DepthTestFunction, withBlend/withoutBlend,
PerspectiveProjection/CachedOrtho matrix buffers, isPanoramicMode, ItemBlockRenderTypes, getBlockRenderer),
RenderTypes.entityCutoutNoCull / itemEntityTranslucentCull, CardinalLightType, CameraRenderState/SkyRenderState/
WeatherRenderState/LevelRenderState mixins, entityAttackRange / isWithinAttackRange / interactOn,
ServerboundInteractPacket.dispatch, TimeChanger getDayTime/setDayTime, ChatComponent.addMessage, OptionsScreen ctor,
Window/Switchable, MipmapGenerator.generateMipLevels, SpawnEggItem Optional<Holder<Item>>, BlockAndTintGetter.

## Round 2 (from CI run with 99 errors)
- handleInventoryMouseClick -> handleContainerInput (confirms ContainerInput guess was right; KeyMappingHelper also compiled)
- GuiGraphicsExtractor: drawString -> text, renderFakeItem -> fakeItem
- RenderTypes.entityCutoutNoCull -> entityCutout, itemEntityTranslucentCull -> entityTranslucentCullItemTarget
- ChargedProjectiles.getItems -> itemCopies; ResourceLoader.registerReloader -> registerReloadListener
- Window -> Switchable cast routed through Object
- build.sh now appends an API dump (apidump.py) to port-report.txt when compile fails
