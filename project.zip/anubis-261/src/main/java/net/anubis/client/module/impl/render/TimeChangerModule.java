package net.anubis.client.module.impl.render;

import net.anubis.client.event.Stage;
import net.anubis.client.event.impl.TickEvent;
import net.anubis.client.module.ClientModule;
import net.anubis.client.module.ModuleCategory;
import net.anubis.client.module.setting.NumberSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;

@Environment(EnvType.CLIENT)
public final class TimeChangerModule extends ClientModule {
   public static volatile TimeChangerModule active;
   private final NumberSetting time = this.addSetting("time", new NumberSetting("Time", 0.0F, -20000.0F, 20000.0F).step(1.0F));
   private long lastApplied = Long.MIN_VALUE;

   public TimeChangerModule() {
      super("time-changer", "Time Changer", "Makes you able to set a custom time.", ModuleCategory.RENDER);
   }

   @Override
   protected void onEnable() {
      active = this;
      this.lastApplied = Long.MIN_VALUE;
      this.on(TickEvent.TYPE, Stage.POST, this::onPostTick);
      invalidate();
   }

   @Override
   protected void onDisable() {
      active = null;
      invalidate();
   }

   private void onPostTick(TickEvent event) {
      long forced = this.forcedDayTime();
      if (forced != this.lastApplied) {
         this.lastApplied = forced;
         invalidate();
      }
   }

   private static void invalidate() {
      ClientLevel level = Minecraft.getInstance().level;
      if (level != null) {
         level.environmentAttributes().invalidateTickCache();
      }
   }

   /** Read by MixinTimeChangerClockManager: replaces the overworld clock's total ticks while enabled. */
   public long forcedDayTime() {
      return (long)this.time.get();
   }
}
