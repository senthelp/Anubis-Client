package net.anubis.client.gui;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.network.chat.Component;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;

@Environment(EnvType.CLIENT)
public final class HudEditorScreen extends Screen {
   public HudEditorScreen() {
      super(Component.literal("ANUBIS HUD Layout"));
   }

   public void removed() {
      super.removed();
      HudLayoutStore.getInstance().save();
   }

   public void onClose() {
      HudLayoutStore.getInstance().save();
      Minecraft.getInstance().setScreen(null);
   }

   public void extractBackground(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY, float partialTick) {
   }

   public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float tickDelta) {
   }

   public boolean isPauseScreen() {
      return false;
   }
}
