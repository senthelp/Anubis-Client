package net.anubis.client.gui;

import net.anubis.client.config.ThemeStore;
import net.anubis.client.imgui.ImGuiManager;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.TitleScreen;

@Environment(EnvType.CLIENT)
public final class AnubisTitleScreen extends TitleScreen {
   private final MainMenuRenderer menu = new MainMenuRenderer(this);

   public static boolean enabled() {
      return ThemeStore.get().customMainMenu.get();
   }

   public void init() {
      ImGuiManager.getInstance().activate(this.menu::render);
   }

   public void tick() {
   }

   public boolean keyPressed(KeyEvent event) {
      return this.menu.keyPressed(event.key()) || super.keyPressed(event);
   }

   public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
      return false;
   }

   public void removed() {
      super.removed();
      ImGuiManager.getInstance().deactivate();
   }

   public void extractBackground(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
   }

   public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
   }

   public boolean shouldCloseOnEsc() {
      return false;
   }

   public boolean isPauseScreen() {
      return false;
   }
}
