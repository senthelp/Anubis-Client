package com.example.client.mixin;

import net.anubis.client.gui.AnubisTitleScreen;
import net.anubis.client.gui.mainmenu.MultiplayerOverlay;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin(JoinMultiplayerScreen.class)
public abstract class MixinMenusJoinMultiplayerScreen extends Screen {
   @Unique
   private MultiplayerOverlay anubis$overlay;

   protected MixinMenusJoinMultiplayerScreen(Component title) {
      super(title);
   }

   @Inject(method = "init", at = @At("TAIL"))
   private void anubis$addOverlay(CallbackInfo ci) {
      this.anubis$overlay = AnubisTitleScreen.enabled() ? new MultiplayerOverlay((JoinMultiplayerScreen)(Object)this) : null;
      if (this.anubis$overlay != null) {
         this.anubis$overlay.show();
      }
   }

   @Inject(method = "repositionElements", at = @At("TAIL"))
   private void anubis$showOverlay(CallbackInfo ci) {
      if (this.anubis$overlay != null) {
         this.anubis$overlay.show();
      }
   }

   @Inject(method = "removed", at = @At("TAIL"))
   private void anubis$hideOverlay(CallbackInfo ci) {
      if (this.anubis$overlay != null) {
         this.anubis$overlay.hide();
      }
   }

   @Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
   private void anubis$overlayKeys(KeyEvent event, CallbackInfoReturnable<Boolean> cir) {
      if (this.anubis$overlay != null && this.anubis$overlay.keyPressed(event.key())) {
         cir.setReturnValue(true);
      }
   }

   public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
      return this.anubis$takesPointer() || super.mouseClicked(event, doubleClick);
   }

   public boolean mouseReleased(MouseButtonEvent event) {
      return this.anubis$takesPointer() || super.mouseReleased(event);
   }

   public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
      return this.anubis$takesPointer() || super.mouseDragged(event, dragX, dragY);
   }

   public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
      return this.anubis$takesPointer() || super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
   }

   @Unique
   private boolean anubis$takesPointer() {
      return this.anubis$overlay != null && this.anubis$overlay.takesPointer();
   }
}
